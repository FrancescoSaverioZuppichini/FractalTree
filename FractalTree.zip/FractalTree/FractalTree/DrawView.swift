import Cocoa

class DrawView: NSView {
    
    override func draw(_ dirtyRect: NSRect) {
        super.draw(dirtyRect)
        
        // Drawing code here.
        
        let path = NSBezierPath(rect: NSMakeRect(dirtyRect.origin.x, dirtyRect.origin.y, dirtyRect.size.width, dirtyRect.size.height));
        
        let grownFactor: CGFloat = 0.6;
        let length:CGFloat = 50.0;
        
       
        NSColor.black.set();
        
        NSBezierPath.strokeLine(from: NSMakePoint(150, 0), to: NSMakePoint(150, length));
        
        let myTransformation = NSAffineTransform()
        myTransformation.rotate(byDegrees: 45.0);
        
        NSBezierPath.strokeLine(from: NSMakePoint(150, 55), to: myTransformation.transform(NSMakePoint(150, length + (length * grownFactor))));
        
        
        path.transform(using: myTransformation as AffineTransform);
         NSBezierPath.strokeLine(from: NSMakePoint(150, 55), to: NSMakePoint(150, length + (length * grownFactor)));
    }
    
}
