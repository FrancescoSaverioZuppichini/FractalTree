//
//  ViewController.swift
//  FractalTree
//
//  Created by Francesco  on 08/12/16.
//  Copyright © 2016 Francesco Saverio Zuppichini. All rights reserved.
//

import Cocoa

class ViewController: NSViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override var representedObject: Any? {
        didSet {
        // Update the view, if already loaded.
        }
    }


}

